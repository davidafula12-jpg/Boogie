const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const { DatabaseSync } = require("node:sqlite"); // built into Node, nothing to install

const PORT = process.env.PORT || 3000;
const LOAN_DAYS = 14;

// ---- Database (a single file: library.db) ----
const db = new DatabaseSync("library.db");
db.exec("PRAGMA foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY, name TEXT UNIQUE COLLATE NOCASE NOT NULL,
    hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member');
  CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY, title TEXT NOT NULL, author TEXT NOT NULL,
    genre TEXT NOT NULL, year INTEGER NOT NULL, copies INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS loans (
    id INTEGER PRIMARY KEY,
    book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    due INTEGER NOT NULL);
`);

// First run: create an admin and a few books
if (!db.prepare("SELECT 1 FROM users LIMIT 1").get()) {
  const pass = process.env.ADMIN_PASSWORD || "admin123";
  db.prepare("INSERT INTO users (name, hash, role) VALUES (?, ?, 'admin')").run("admin", bcrypt.hashSync(pass, 10));
  console.log("Created admin account. Username: admin. Change this password before sharing the site.");
}
if (!db.prepare("SELECT 1 FROM books LIMIT 1").get()) {
  const add = db.prepare("INSERT INTO books (title, author, genre, year, copies) VALUES (?, ?, ?, ?, ?)");
  [["Things Fall Apart", "Chinua Achebe", "Fiction", 1958, 3],
   ["Cosmos", "Carl Sagan", "Science", 1980, 1],
   ["Tumbo Lisilo Shiba", "Ken Walibora", "Fiction", 2017, 2],
   ["Unbowed", "Wangari Maathai", "History", 2006, 2],
   ["Song of Lawino", "Okot p’Bitek", "Poetry", 1966, 2],
   ["The Gruffalo", "Julia Donaldson", "Kids", 1999, 3]].forEach((b) => add.run(...b));
}

// ---- App setup ----
const app = express();
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-only-secret-change-me",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 7 * 864e5 },
}));
app.use(express.static("public"));

const needLogin = (req, res, next) => (req.session.user ? next() : res.status(401).json({ error: "Please sign in." }));
const needAdmin = (req, res, next) => (req.session.user?.role === "admin" ? next() : res.status(403).json({ error: "Admins only." }));
const login = (req, u) => { req.session.user = { id: u.id, name: u.name, role: u.role }; return req.session.user; };

// ---- Accounts ----
app.post("/api/signup", (req, res) => {
  const name = String(req.body.name || "").trim(), pass = String(req.body.pass || "");
  if (name.length < 3) return res.status(400).json({ error: "Username needs at least 3 characters." });
  if (pass.length < 6) return res.status(400).json({ error: "Password needs at least 6 characters." });
  if (db.prepare("SELECT 1 FROM users WHERE name = ?").get(name)) return res.status(409).json({ error: "That username is taken. Choose another." });
  const r = db.prepare("INSERT INTO users (name, hash) VALUES (?, ?)").run(name, bcrypt.hashSync(pass, 10));
  res.json(login(req, { id: r.lastInsertRowid, name, role: "member" }));
});

app.post("/api/login", (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE name = ?").get(String(req.body.name || "").trim());
  if (!u || !bcrypt.compareSync(String(req.body.pass || ""), u.hash)) return res.status(401).json({ error: "Wrong username or password." });
  res.json(login(req, u));
});

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/me", (req, res) => res.json(req.session.user || null));

// ---- Books ----
app.get("/api/books", needLogin, (req, res) => {
  res.json(db.prepare(`SELECT b.*, b.copies - (SELECT COUNT(*) FROM loans l WHERE l.book_id = b.id) AS available
                       FROM books b ORDER BY b.title`).all());
});

app.post("/api/books", needLogin, needAdmin, (req, res) => {
  const { title, author, genre, year, copies } = req.body;
  if (!title?.trim() || !author?.trim() || !genre || !(+year > 0) || !(+copies > 0)) return res.status(400).json({ error: "Fill in every field." });
  const r = db.prepare("INSERT INTO books (title, author, genre, year, copies) VALUES (?, ?, ?, ?, ?)")
    .run(title.trim(), author.trim(), genre, +year, +copies);
  res.json({ id: r.lastInsertRowid });
});

app.delete("/api/books/:id", needLogin, needAdmin, (req, res) => {
  db.prepare("DELETE FROM books WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

// ---- Loans ----
app.get("/api/loans", needLogin, (req, res) => {
  const sql = `SELECT l.id, l.book_id, l.due, u.name AS user FROM loans l JOIN users u ON u.id = l.user_id`;
  const me = req.session.user;
  res.json(me.role === "admin" ? db.prepare(sql).all() : db.prepare(sql + " WHERE l.user_id = ?").all(me.id));
});

app.post("/api/loans", needLogin, (req, res) => {
  const me = req.session.user, id = +req.body.bookId;
  if (me.role === "admin") return res.status(403).json({ error: "Admins manage the catalog. Use a member account to borrow." });
  const book = db.prepare("SELECT *, copies - (SELECT COUNT(*) FROM loans WHERE book_id = books.id) AS available FROM books WHERE id = ?").get(id);
  if (!book) return res.status(404).json({ error: "Book not found." });
  if (book.available < 1) return res.status(409).json({ error: "All copies are out." });
  if (db.prepare("SELECT 1 FROM loans WHERE book_id = ? AND user_id = ?").get(id, me.id)) return res.status(409).json({ error: "You already have this book." });
  db.prepare("INSERT INTO loans (book_id, user_id, due) VALUES (?, ?, ?)").run(id, me.id, Date.now() + LOAN_DAYS * 864e5);
  res.json({ ok: true });
});

app.delete("/api/loans/:id", needLogin, (req, res) => {
  const me = req.session.user;
  const loan = db.prepare("SELECT * FROM loans WHERE id = ?").get(req.params.id);
  if (!loan) return res.status(404).json({ error: "Loan not found." });
  if (me.role !== "admin" && loan.user_id !== me.id) return res.status(403).json({ error: "That isn’t your loan." });
  db.prepare("DELETE FROM loans WHERE id = ?").run(loan.id);
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Library running at http://localhost:${PORT}`));
